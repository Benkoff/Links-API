
# LinksPostRequestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | **String** | the user which saved the link |  [optional]
**url** | **String** | the link been saved before |  [optional]
**label** | **String** | a label given by user |  [optional]
**reference** | **String** | a reference assigned by user |  [optional]



