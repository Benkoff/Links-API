
# LinksRequestResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | link&#x60;s ID at database |  [optional]
**user** | **String** | the user which saved the link |  [optional]
**url** | **String** | the link been saved before |  [optional]
**label** | **String** | a label given by user |  [optional]
**reference** | **String** | a reference assigned by user |  [optional]
**active** | **Boolean** | active links only are visible to the user specified |  [optional]



